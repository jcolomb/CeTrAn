### R code from vignette source 'adehabitatMA.Rnw'

###################################################
### code chunk number 1: adehabitatMA.Rnw:28-32
###################################################
oldopt <- options(width=80, warn=-1)
.PngNo <- 0
wi <- 480
pt <- 20


###################################################
### code chunk number 2: afig (eval = FALSE)
###################################################
## .PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
##           .PngNo, ".png", sep="")
## png(file=file, width = wi, height = wi, pointsize = pt)


###################################################
### code chunk number 3: zfig (eval = FALSE)
###################################################
## dev.null <- dev.off()
## cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 4: zfigg (eval = FALSE)
###################################################
## dev.null <- dev.off()
## cat("\\includegraphics[height=14cm,width=14cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 5: adehabitatMA.Rnw:103-104
###################################################
library(adehabitatMA)


###################################################
### code chunk number 6: adehabitatMA.Rnw:107-109
###################################################
set.seed(13431)
adeoptions(shortprint=TRUE)


###################################################
### code chunk number 7: adehabitatMA.Rnw:129-130
###################################################
data(lynxjura)


###################################################
### code chunk number 8: adehabitatMA.Rnw:142-143
###################################################
head(lynxjura$locs)


###################################################
### code chunk number 9: adehabitatMA.Rnw:150-151
###################################################
lynxjura$map


###################################################
### code chunk number 10: figu1 (eval = FALSE)
###################################################
## mimage(lynxjura$map)


###################################################
### code chunk number 11: adehabitatMA.Rnw:161-162 (eval = FALSE)
###################################################
## mimage(lynxjura$map)


###################################################
### code chunk number 12: adehabitatMA.Rnw:166-169
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
mimage(lynxjura$map)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 13: adehabitatMA.Rnw:184-185
###################################################
adeoptions(shortprint=TRUE)


###################################################
### code chunk number 14: adehabitatMA.Rnw:190-191
###################################################
lynxjura$map


###################################################
### code chunk number 15: adehabitatMA.Rnw:211-212 (eval = FALSE)
###################################################
## explore(lynxjura$map)


###################################################
### code chunk number 16: adehabitatMA.Rnw:223-224 (eval = FALSE)
###################################################
## explore(lynxjura$map, panel.last=function() points(lynxjura$locs, pch=3))


###################################################
### code chunk number 17: adehabitatMA.Rnw:234-235
###################################################
map <- lynxjura$map


###################################################
### code chunk number 18: sodssss (eval = FALSE)
###################################################
## hist(map)


###################################################
### code chunk number 19: adehabitatMA.Rnw:244-245 (eval = FALSE)
###################################################
## hist(map)


###################################################
### code chunk number 20: adehabitatMA.Rnw:249-252
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
hist(map)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 21: qsfddfdd (eval = FALSE)
###################################################
## forest <- map[,1]
## forest[[1]][forest[[1]]<95] <- NA
## image(forest, col="green")


###################################################
### code chunk number 22: adehabitatMA.Rnw:267-268 (eval = FALSE)
###################################################
## forest <- map[,1]
## forest[[1]][forest[[1]]<95] <- NA
## image(forest, col="green")


###################################################
### code chunk number 23: adehabitatMA.Rnw:273-276
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
forest <- map[,1]
forest[[1]][forest[[1]]<95] <- NA
image(forest, col="green")
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 24: ksdkksss (eval = FALSE)
###################################################
## lab <- labcon(forest)
## image(lab)


###################################################
### code chunk number 25: adehabitatMA.Rnw:290-291 (eval = FALSE)
###################################################
## lab <- labcon(forest)
## image(lab)


###################################################
### code chunk number 26: adehabitatMA.Rnw:295-298
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
lab <- labcon(forest)
image(lab)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 27: adehabitatMA.Rnw:307-309
###################################################
lab
max(lab[[1]])


###################################################
### code chunk number 28: adehabitatMA.Rnw:315-316
###################################################
gridparameters(lab)


###################################################
### code chunk number 29: adehabitatMA.Rnw:321-322
###################################################
table(lab[[1]])*500*500


###################################################
### code chunk number 30: adehabitatMA.Rnw:333-335
###################################################
fullgrid(lab) <- TRUE
fullgrid(map) <- TRUE


###################################################
### code chunk number 31: adehabitatMA.Rnw:340-341
###################################################
mean(map[[2]][lab[[1]]==1], na.rm=TRUE)


###################################################
### code chunk number 32: sldsss (eval = FALSE)
###################################################
## comp1 <- map[2]
## comp1[[1]][map[[1]]<95] <- NA
## comp1[[1]][lab[[1]]!=1] <- NA
## image(comp1)


###################################################
### code chunk number 33: adehabitatMA.Rnw:354-355 (eval = FALSE)
###################################################
## comp1 <- map[2]
## comp1[[1]][map[[1]]<95] <- NA
## comp1[[1]][lab[[1]]!=1] <- NA
## image(comp1)


###################################################
### code chunk number 34: adehabitatMA.Rnw:359-362
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
comp1 <- map[2]
comp1[[1]][map[[1]]<95] <- NA
comp1[[1]][lab[[1]]!=1] <- NA
image(comp1)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 35: skks (eval = FALSE)
###################################################
## image(forest, col="red")


###################################################
### code chunk number 36: adehabitatMA.Rnw:376-377 (eval = FALSE)
###################################################
## image(forest, col="red")


###################################################
### code chunk number 37: adehabitatMA.Rnw:381-384
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(forest, col="red")
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 38: adehabitatMA.Rnw:391-392
###################################################
con <- getcontour(forest)


###################################################
### code chunk number 39: ssskkkq (eval = FALSE)
###################################################
## plot(con, col="green")


###################################################
### code chunk number 40: adehabitatMA.Rnw:419-420 (eval = FALSE)
###################################################
## plot(con, col="green")


###################################################
### code chunk number 41: adehabitatMA.Rnw:424-427
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
plot(con, col="green")
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 42: adehabitatMA.Rnw:450-452
###################################################
for1 <- morphology(forest, "dilate", nt=1)
for1


###################################################
### code chunk number 43: sdkskss (eval = FALSE)
###################################################
## image(for1, col="blue")
## image(forest, col="yellow", add=TRUE)


###################################################
### code chunk number 44: adehabitatMA.Rnw:464-465 (eval = FALSE)
###################################################
## image(for1, col="blue")
## image(forest, col="yellow", add=TRUE)


###################################################
### code chunk number 45: adehabitatMA.Rnw:469-472
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(for1, col="blue")
image(forest, col="yellow", add=TRUE)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 46: skkssss (eval = FALSE)
###################################################
## plot(getcontour(for1), col="green")


###################################################
### code chunk number 47: adehabitatMA.Rnw:484-485 (eval = FALSE)
###################################################
## plot(getcontour(for1), col="green")


###################################################
### code chunk number 48: adehabitatMA.Rnw:489-492
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
plot(getcontour(for1), col="green")
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 49: skdskdk (eval = FALSE)
###################################################
## map <- lynxjura$map
## mimage(map)


###################################################
### code chunk number 50: adehabitatMA.Rnw:516-517 (eval = FALSE)
###################################################
## map <- lynxjura$map
## mimage(map)


###################################################
### code chunk number 51: adehabitatMA.Rnw:521-524
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
map <- lynxjura$map
mimage(map)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 52: adehabitatMA.Rnw:530-531
###################################################
gridparameters(map)


###################################################
### code chunk number 53: sssshhh (eval = FALSE)
###################################################
## mimage(lowres(map, 10))


###################################################
### code chunk number 54: adehabitatMA.Rnw:544-545 (eval = FALSE)
###################################################
## mimage(lowres(map, 10))


###################################################
### code chunk number 55: adehabitatMA.Rnw:549-552
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
mimage(lowres(map, 10))
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 56: sqkdksssq (eval = FALSE)
###################################################
## map[[1]] <- as.numeric(cut(map[[1]],3))
## image(map, 1)


###################################################
### code chunk number 57: adehabitatMA.Rnw:567-568 (eval = FALSE)
###################################################
## map[[1]] <- as.numeric(cut(map[[1]],3))
## image(map, 1)


###################################################
### code chunk number 58: adehabitatMA.Rnw:572-575
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
map[[1]] <- as.numeric(cut(map[[1]],3))
image(map, 1)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 59: sdskkkk (eval = FALSE)
###################################################
## image(lowres(map, 10, which.fac=1))


###################################################
### code chunk number 60: adehabitatMA.Rnw:591-592 (eval = FALSE)
###################################################
## image(lowres(map, 10, which.fac=1))


###################################################
### code chunk number 61: adehabitatMA.Rnw:596-599
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(lowres(map, 10, which.fac=1))
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 62: skssjdx (eval = FALSE)
###################################################
## image(forest, col="green")
## box()


###################################################
### code chunk number 63: adehabitatMA.Rnw:614-615 (eval = FALSE)
###################################################
## image(forest, col="green")
## box()


###################################################
### code chunk number 64: adehabitatMA.Rnw:619-622
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(forest, col="green")
box()
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 65: adehabitatMA.Rnw:629-630 (eval = FALSE)
###################################################
## for2 <- subsetmap(forest)


###################################################
### code chunk number 66: adehabitatMA.Rnw:636-638
###################################################
for2 <- subsetmap(forest, xlim=c(850254.2, 878990.2),
                  ylim=c(2128744, 2172175))


###################################################
### code chunk number 67: skksks (eval = FALSE)
###################################################
## image(for2, col="green")
## box()


###################################################
### code chunk number 68: adehabitatMA.Rnw:646-647 (eval = FALSE)
###################################################
## image(for2, col="green")
## box()


###################################################
### code chunk number 69: adehabitatMA.Rnw:651-654
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(for2, col="green")
box()
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 70: adehabitatMA.Rnw:690-695
###################################################
data(lynxjura)
map <- lynxjura$map
class(map)
locs <- lynxjura$loc
class(locs)


###################################################
### code chunk number 71: flkqskqfkjc (eval = FALSE)
###################################################
## image(map, 1)
## points(locs, pch=3)


###################################################
### code chunk number 72: adehabitatMA.Rnw:705-706 (eval = FALSE)
###################################################
## image(map, 1)
## points(locs, pch=3)


###################################################
### code chunk number 73: adehabitatMA.Rnw:710-713
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(map, 1)
points(locs, pch=3)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 74: adehabitatMA.Rnw:719-720
###################################################
cp <- count.points(locs, map)


###################################################
### code chunk number 75: ssckcc (eval = FALSE)
###################################################
## image(cp)


###################################################
### code chunk number 76: adehabitatMA.Rnw:741-742 (eval = FALSE)
###################################################
## image(cp)


###################################################
### code chunk number 77: adehabitatMA.Rnw:746-749
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(cp)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 78: adehabitatMA.Rnw:762-763
###################################################
head(locs)


###################################################
### code chunk number 79: adehabitatMA.Rnw:773-775
###################################################
cpr <- count.points(locs[,"Type"], map)
cpr


###################################################
### code chunk number 80: sdkkckck (eval = FALSE)
###################################################
## mimage(cpr)


###################################################
### code chunk number 81: adehabitatMA.Rnw:784-785 (eval = FALSE)
###################################################
## mimage(cpr)


###################################################
### code chunk number 82: adehabitatMA.Rnw:789-792
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
mimage(cpr)
dev.null <- dev.off()
cat("\\includegraphics[height=14cm,width=14cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 83: adehabitatMA.Rnw:806-807
###################################################
df <- join(locs, map)


###################################################
### code chunk number 84: adehabitatMA.Rnw:813-814
###################################################
head(df)


###################################################
### code chunk number 85: adehabitatMA.Rnw:833-835
###################################################
asc <- ascgen(locs, cellsize=5000)
asc


###################################################
### code chunk number 86: llldcvdv (eval = FALSE)
###################################################
## image(asc)


###################################################
### code chunk number 87: adehabitatMA.Rnw:846-847 (eval = FALSE)
###################################################
## image(asc)


###################################################
### code chunk number 88: adehabitatMA.Rnw:851-854
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(asc)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 89: adehabitatMA.Rnw:867-868
###################################################
po <- locs[locs[["Type"]]=="O",]


###################################################
### code chunk number 90: sfjkfc (eval = FALSE)
###################################################
## image(buffer(po, map, 3000))


###################################################
### code chunk number 91: adehabitatMA.Rnw:878-879 (eval = FALSE)
###################################################
## image(buffer(po, map, 3000))


###################################################
### code chunk number 92: adehabitatMA.Rnw:883-886
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(buffer(po, map, 3000))
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 93: sdskwkl (eval = FALSE)
###################################################
## plot(con)


###################################################
### code chunk number 94: adehabitatMA.Rnw:897-898 (eval = FALSE)
###################################################
## plot(con)


###################################################
### code chunk number 95: adehabitatMA.Rnw:902-905
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
plot(con)
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 96: dfkwkfckj (eval = FALSE)
###################################################
## image(buffer(con, map, 3000))


###################################################
### code chunk number 97: adehabitatMA.Rnw:916-917 (eval = FALSE)
###################################################
## image(buffer(con, map, 3000))


###################################################
### code chunk number 98: adehabitatMA.Rnw:921-924
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
image(buffer(con, map, 3000))
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 99: qksdk (eval = FALSE)
###################################################
## sl <- as(con, "SpatialLines")
## image(buffer(sl, map, 500))


###################################################
### code chunk number 100: adehabitatMA.Rnw:938-939 (eval = FALSE)
###################################################
## sl <- as(con, "SpatialLines")
## image(buffer(sl, map, 500))


###################################################
### code chunk number 101: adehabitatMA.Rnw:943-946
###################################################
.PngNo <- .PngNo + 1; file <- paste("Fig-bitmap-",
          .PngNo, ".png", sep="")
png(file=file, width = wi, height = wi, pointsize = pt)
sl <- as(con, "SpatialLines")
image(buffer(sl, map, 500))
dev.null <- dev.off()
cat("\\includegraphics[height=7cm,width=7cm]{", file, "}\n\n", sep="")


###################################################
### code chunk number 102: adehabitatMA.Rnw:983-984
###################################################
options(oldopt)


